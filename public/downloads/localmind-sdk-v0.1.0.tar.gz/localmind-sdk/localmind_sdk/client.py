"""Typed, loopback-only client for LocalMind's local agent API."""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any, Mapping
from urllib.parse import urlsplit

import httpx


class LocalMindError(RuntimeError):
    """A LocalMind API or local model runtime failure."""


@dataclass(frozen=True)
class AgentEvent:
    event: str
    data: Mapping[str, Any]


class LocalMindClient:
    """Call the same local model and agent gateway used by JARVIS.

    The endpoint must resolve to loopback. This prevents accidental use of this
    SDK as a client for a public or cloud inference endpoint.
    """

    def __init__(self, base_url: str = "http://127.0.0.1:8420", timeout: float = 600.0):
        parsed = urlsplit(base_url)
        if parsed.scheme not in {"http", "https"} or parsed.hostname not in {
            "localhost", "127.0.0.1", "::1"
        }:
            raise ValueError("LocalMind SDK only accepts loopback API addresses")
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(base_url=self.base_url, timeout=timeout, trust_env=False)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> LocalMindClient:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def _get(self, path: str) -> dict | list:
        response = self._client.get(path)
        return self._decode(response)

    @staticmethod
    def _decode(response: httpx.Response) -> dict | list:
        if response.is_error:
            try:
                detail = response.json().get("detail", response.text)
            except (ValueError, AttributeError):
                detail = response.text
            raise LocalMindError(f"LocalMind API returned HTTP {response.status_code}: {detail}")
        return response.json()

    def health(self) -> dict:
        return self._get("/api/health")  # type: ignore[return-value]

    def models(self) -> list[dict]:
        return self._get("/api/models")  # type: ignore[return-value]

    def agents(self) -> dict:
        return self._get("/api/jarvis/agents")  # type: ignore[return-value]

    def workflows(self) -> list[dict]:
        return self._get("/api/workflows")  # type: ignore[return-value]

    def runtime_status(self) -> dict:
        return self._get("/api/jarvis/status")  # type: ignore[return-value]

    def system(self, category: str = "health") -> dict:
        return self._get(f"/api/jarvis/system/{category}")  # type: ignore[return-value]

    def runs(self) -> list[dict]:
        return self._get("/api/runs")  # type: ignore[return-value]

    def run_workflow(self, workflow_id: str, inputs: Mapping[str, Any] | None = None) -> dict:
        response = self._client.post(f"/api/workflows/{workflow_id}/run", json=dict(inputs or {}))
        return self._decode(response)  # type: ignore[return-value]

    def resume_workflow(self, run_id: str, *, approved: bool, feedback: str | None = None) -> dict:
        response = self._client.post(f"/api/runs/{run_id}/resume",
                                     json={"approved": approved, "feedback": feedback})
        return self._decode(response)  # type: ignore[return-value]

    def chat(self, prompt: str, *, session_id: str | None = None, mode: str = "chat",
             context: str = "", workspace_id: str | None = None) -> dict:
        response = self._client.post("/api/jarvis/chat", json={
            "prompt": prompt, "session_id": session_id, "mode": mode,
            "context": context, "workspace_id": workspace_id, "stream": False,
        })
        return self._decode(response)  # type: ignore[return-value]

    def stream_chat(self, prompt: str, *, session_id: str | None = None, mode: str = "chat",
                    context: str = "", workspace_id: str | None = None) -> Iterator[AgentEvent]:
        payload = {"prompt": prompt, "session_id": session_id, "mode": mode,
                   "context": context, "workspace_id": workspace_id, "stream": True}
        with self._client.stream("POST", "/api/jarvis/chat", json=payload) as response:
            if response.is_error:
                self._decode(response)
            event_name = "message"
            data_lines: list[str] = []
            for line in response.iter_lines():
                if line.startswith("event:"):
                    event_name = line.partition(":")[2].strip()
                elif line.startswith("data:"):
                    data_lines.append(line.partition(":")[2].strip())
                elif not line and data_lines:
                    value = "\n".join(data_lines)
                    data_lines.clear()
                    if value != "[DONE]":
                        try:
                            yield AgentEvent(event_name, json.loads(value))
                        except json.JSONDecodeError as exc:
                            raise LocalMindError(f"Invalid LocalMind event payload: {value[:200]}") from exc
                    event_name = "message"

